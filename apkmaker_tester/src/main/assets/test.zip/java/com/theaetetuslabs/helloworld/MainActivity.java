package com.theaetetuslabs.helloworld;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.webkit.WebView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = (WebView)findViewById(R.id.webview);
        AssetManager am = getAssets();
        try {
            InputStream is = am.open("MyHtml.html");
            BufferedReader bis = new BufferedReader(new InputStreamReader(is));
            StringBuilder sb = new StringBuilder();
            String line;
            while((line = bis.readLine())!=null){
                sb.append(line).append("\n");
            }
            bis.close();
            webView.loadData(sb.toString(), "text/html", "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
